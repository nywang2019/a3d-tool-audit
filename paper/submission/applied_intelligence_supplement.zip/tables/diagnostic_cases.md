| Case | Model | Rule-derived diagnosis | Trace fidelity | Trial ID |
|---|---:|---:|---:|---:|
| D1 | DeepSeek-V4.1-Flash | Executable goal-irrelevant tool | 0.861 | d3-x5-g5-r0 |
| K1 | Kimi K3.1 Pro | Wrong argument value | 0.857 | d3-x5-g0-r0 |
| G1 | GLM-5.3-Flashx | Premature dependency | 0.750 | d3-x5-g2-r0 |
| M1 | MiniMax-M3.1-Flash | Irrelevant function calls | 0.719 | d3-x5-g1-r0 |
| Q1 | Qwen3.8-Max | Premature final answer | 0.646 | d3-x5-g13-r0 |
