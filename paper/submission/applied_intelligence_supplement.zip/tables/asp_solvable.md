| Model | Solvable graphs | ASP_solvable [95% CI] | Sign-flip p | Holm p |
|---|---:|---:|---:|---:|
| DeepSeek-V4.1-Flash | 15 | +20.0 pp [-3.3, +43.3] | 0.219 | 0.656 |
| Kimi K3.1 Pro | 11 | +18.2 pp [-4.5, +40.9] | 0.312 | 0.656 |
| GLM-5.3-Flashx | 4 | +50.0 pp [+12.5, +87.5] | 0.250 | 0.656 |
| MiniMax-M3.1-Flash | 12 | +37.5 pp [+12.5, +62.5] | 0.047 | 0.234 |
| Qwen3.8-Max | 12 | +25.0 pp [+0.0, +50.0] | 0.156 | 0.625 |
