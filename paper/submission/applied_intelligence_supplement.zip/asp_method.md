# ASP as a paired-loss summary

## Construct

ASP is a historical metric name for the average within-graph paired loss.
Conditions D5, I5, and E5 contain the five disconnected tools
`d1,...,d5`, the five connected-incompatible tools `i1,...,i5`, and the five
executable goal-irrelevant tools `e1,...,e5`, respectively. The tools in E5 are
connected, type-compatible, and able to run, but lie outside the required tool
chain. All three conditions use the same required graph.

For model \(m\) and graph \(g\), let
\(Y_{\mathrm{D5}},Y_{\mathrm{I5}},Y_{\mathrm{E5}}\in\{0,1\}\) denote exact
success outcomes in D5, I5, and E5. The graph score and model score are:

\[
a_{m,g}=\frac{Y_{\mathrm{D5}}+Y_{\mathrm{I5}}}{2}-Y_{\mathrm{E5}},
\qquad
\operatorname{ASP}_m=100\,
\mathbb{E}_g[a_{m,g}].
\]

Units are percentage points. A positive score means that the executable
goal-irrelevant condition has a lower exact success rate than the average of the
two controls. The components
\(Y_{\mathrm{D5}}-Y_{\mathrm{E5}}\) and
\(Y_{\mathrm{I5}}-Y_{\mathrm{E5}}\) remain visible so the metric does not
conceal how the two contrasts contribute.

## Inference

- The graph is the resampling unit.
- Confidence intervals use a deterministic 4,000-sample graph bootstrap.
- The two-sided sign-flip test uses the exact distribution of graph-level scores
  under sign symmetry.
- Holm correction is applied across five models.
- `ASP_solvable` repeats the calculation only on graphs solved without extra
  tools and is explicitly a sensitivity analysis.

## Interpretation limits

ASP is a descriptive paired loss, not a causal mediation estimate. The three
tool-usability properties and associated graph structure remain bundled across
the three non-baseline conditions. A positive ASP therefore supports a
condition-specific paired loss in this design; it does not identify a single
internal mechanism. Equal weighting of the two control contrasts is a
pre-specified design choice.

The result is also bounded to five model aliases, one function-dependency
family, depth three, and 15 shared control graphs.
